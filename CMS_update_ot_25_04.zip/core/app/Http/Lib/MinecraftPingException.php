<?php

namespace App\Http\Lib;

class MinecraftPingException extends \Exception
{
	// Exception thrown by MinecraftPing class
}
