<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RatingsSetting extends Model {
    
	protected $table = "ratings_settings";

}
