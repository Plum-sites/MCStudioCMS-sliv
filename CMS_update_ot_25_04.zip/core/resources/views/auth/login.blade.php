@extends('frontend.layouts.master')
@section('body')

@endsection