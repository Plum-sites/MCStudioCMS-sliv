<div class="table-responsive">
    <table class="table table-lg table-expand w-100">
        <thead>
            <tr>
                <th style="min-width:60px;">ID</th>
                <th style="max-width:20px;">
                	<i class="fa fa-image" style="font-size:16px;padding:5px;line-height:7px;"></i>
                </th>
                <th style="min-width:150px;">ПРЕДМЕТ</th>
                <th style="min-width:150px;">СЕРВЕР</th>
                <th style="min-width:150px;">КАТЕГОРИЯ</th>
                <th style="min-width:80px;">ЦЕНА ЗА КОЛ-ВО</th>
                <th style="min-width:170px;"></th>
            </tr>
        </thead>
        <tbody>
        	<?php if(count(@$items) <= 0): ?>
                <tr class="table-row text-center">
                    <td colspan="7">В данный момент в выбранной категории товаров нет</td>
                </tr>
            <?php else: ?>
            	<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="wow pulse" data-wow-delay="0.3s">
                        <td>
                            <span>
                                <?php echo e(@$item->id); ?>

                            </span>
                        </td>
                        <td>
                        	<img src="<?php echo e(asset('assets/minecraft/items')); ?>/<?php echo e((!@$item->image) ? 'default.png' : @$item->image); ?>" width="20" height="20">
                        </td>
                        <td>
                            <span>
                                <?php echo e(@$item->name); ?>

                            </span>
                        </td>
                        <td>
                            <span>
                                <?php echo e(@$item->servers->name); ?>

                            </span>
                        </td>
                        <td>
                            <span>
                                <?php echo e(@$item->category->name); ?>

                            </span>
                        </td>
                        <td>
                            <span>
                                <?php echo e(@$item->price); ?> руб. за <?php echo e(@$item->count); ?> шт.
                            </span>
                        </td>
                        <td>
                            <form id="form_item_dels<?php echo e(@$item->id); ?>" role="form" action="<?php echo e(route('admin.serversList.adds')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e(@$item->id); ?>">
                                <button type="button" class="btn btn-sm btn-outline-info" style="font-size: 15px;"
                                    data-toggle="modal"
                                    data-target="#item<?php echo e(@$item->id); ?>"
                                    data-id="<?php echo e(@$item->id); ?>"
                                    data-item-name="<?php echo e(@$item->name); ?>"
                                    data-item-description="<?php echo e(@$item->description); ?>"
                                    data-item-server-id="<?php echo e(@$item->servers->id); ?>"
                                    data-item-server-name="<?php echo e(@$item->servers->name); ?>"
                                    data-item-category-id="<?php echo e(@$item->category->id); ?>"
                                    data-item-category-name="<?php echo e(@$item->category->name); ?>"
                                    data-item-item-id="<?php echo e(@$item->item_id); ?>"
                                    data-item-count="<?php echo e(@$item->count); ?>"
                                    data-item-price="<?php echo e(@$item->price); ?>"
                                    data-item-image="<?php echo e(@$item->image); ?>"
                                    data-item-status="<?php echo e(@$item->status); ?>"
                                >
                                    Изменить
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-danger item_dels" style="font-size: 15px;" data-id="<?php echo e(@$item->id); ?>">
                                    <i class="fa fa-trash" style="margin:0 2px;"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="item<?php echo e(@$item->id); ?>" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h4 class="modal-title w-100 font-weight-bold text-left text-black">Предмет <u><?php echo e(@$item->name); ?></u></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form_item_<?php echo e(@$item->id); ?>" role="form" action="<?php echo e(route('admin.itemsList.adds')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e(@$item->id); ?>">
                <div class="modal-body">
                    <div class="portlet light bordered">
                        <div class="portlet-body form">
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="justify-content-center text-center">
                                            <img id="item_img_preview_<?php echo e(@$item->id); ?>" src="<?php echo e(asset('assets/minecraft/items')); ?>/<?php echo e((!@$item->image) ? 'default.png' : @$item->image); ?>" width="85" height="85">
                                        </div>
                                        <div class="form-group">
                                            <label for="">
                                                <b style="font-size: 16px;">Картинка</b>
                                            </label>
                                            <div class="input-group">
                                                <input type="file" id="item_img_input_save" name="image" class="custom-input-file" />
                                                <label for="item_img_input_save">
                                                    <i class="fas fa-upload"></i>
                                                    <span>Выберите файл…</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="row">
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">Название предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <input type="text" name="name" class="form-control" placeholder="Алмаз" value="<?php echo e(@$item->name); ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <i class="fas fa-pencil-alt"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">Кол-во предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <input type="text" name="count" class="form-control" placeholder="8" value="<?php echo e(@$item->count); ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <i class="fa fa-sort-numeric-desc"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">Сервер предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <select class="form-control select-max-width" id="server_id_<?php echo e(@$item->id); ?>" name="server_id">
                                                        <option value="" selected disabled>Выберите сервер предмета</option>
                                                        <?php $__currentLoopData = @$servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e(@$server->id); ?>" data-server-id="<?php echo e(@$server->id); ?>" data-server-name="<?php echo e(@$server->name); ?>" <?php echo e((@$item->server_id == @$server->id) ? 'selected' : ''); ?>><?php echo e(@$server->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">ID предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <input type="text" name="item_id" class="form-control" placeholder="ID:DATAID" value="<?php echo e(@$item->item_id); ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <i class="fa fa-cube"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">Стоимость предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <input type="text" name="price" class="form-control" placeholder="10" value="<?php echo e(@$item->price); ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <i class="fas fa-ruble-sign"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="">
                                                    <b style="font-size: 16px;">Категория предмета</b>
                                                </label>
                                                <div class="input-group">
                                                    <!-- <input type="hidden" name="category_id" value="0">
                                                    <input type="text" name="category_id_x" class="form-control" placeholder="Category" value="Category" readonly="">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <i class="fa fa-cubes"></i>
                                                        </span>
                                                    </div> -->
                                                    <select class="form-control select-max-width" id="category_id_<?php echo e(@$item->id); ?>" name="category_id">
                                                        <option value="" selected disabled>Выберите категорию предмета</option>
                                                        <?php
                                                        $categorys = App\Category::where('server_id', '=', @$item->server_id)->get();
                                                        ?>
                                                        <?php $__currentLoopData = @$categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e(@$category->id); ?>" data-category-id="<?php echo e(@$category->id); ?>" data-category-name="<?php echo e(@$category->name); ?>" <?php echo e((@$item->category_id == @$category->id) ? 'selected' : ''); ?>><?php echo e(@$category->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="status" value="1" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-on="Сервер активен" data-off="Сервер не активен" data-width="100%">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary btn-block item_save" data-id="<?php echo e(@$item->id); ?>">
                        Сохранить
                    </button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Закрыть</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
$('#server_id_<?php echo e(@$item->id); ?>').on('change', function() {
    var serv_id = $(this).val();
    var item_id = '<?php echo e(@$item->id); ?>';
    var category_id = '<?php echo e(@$item->category_id); ?>';
    $.ajax({
        type: 'POST',
        url: '<?php echo e(route('admin.itemsList.load')); ?>',
        data: {
            action: 'list',
            _token: csrf_token,
            items_list_server_id: serv_id
        },
        success: function (data) {
            // console.log(data);
            $('#category_id_' + item_id).html('');
            $('#category_id_' + item_id).val('');
            $('#category_id_' + item_id).html('<option value="" selected disabled>Выберите категорию товара</option>');
            $.each(data, function (index, value) {
                $('#category_id_' + item_id).append('<option value="' + value.id + '" data-category-id="' + value.id + '" data-category-name="' + value.name + '">' + value.name + '</option>');
            });
            $('#category_id_' + item_id).val('');
        },
        error: function(data) {
            $('#category_id_' + item_id).html('');
            $('#category_id_' + item_id).html('<option value="" selected disabled>Выберите категорию товара</option>');
        }
    });
});
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">

    $(document).on('change', '.item_img_input_save', function () {
        var item_id = $(this).data('item-id');
        logoURL(this, 'item_img_preview_' + item_id);
    });

    $('.item_save').on('click', function() {
        var id = $(this).data('id');
        $(this).attr('disabled', true);
        var form = $('#form_item_' + id)[0];
        var form_data = new FormData(form);
        $.ajax({
            type: "POST",
            url: "<?php echo e(route('admin.itemsList.save')); ?>",
            data: form_data,
            contentType: false,
            processData: false,
            success: function(data) {
                notify(data.message, 8000, data.type);
                $('.item_save').attr('disabled', false);
                if(data.type == "success") {
                    $('#item' + id).modal('hide');
                    $('body').removeClass('modal-open');
                    $('.modal-backdrop').remove();
                    load_content();
                }
            },
            error: function(data) {
                $('.item_save').attr('disabled', false);
            }
        });
    });

    $('.item_dels').on('click', function() {
        var id = $(this).data('id');
        $(this).attr('disabled', true);
        var form = $('#form_item_dels' + id)[0];
        var form_data = new FormData(form);
        $.ajax({
            type: "POST",
            url: "<?php echo e(route('admin.itemsList.dels')); ?>",
            data: form_data,
            contentType: false,
            processData: false,
            success: function(data) {
                notify(data.message, 8000, data.type);
                $('.item_dels').attr('disabled', false);
                if(data.type == "success") {
                    load_content();
                }
            },
            error: function(data) {
                console.log(data);
                $('.item_dels').attr('disabled', false);
            }
        });
    });

</script><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/itemsList-list.blade.php ENDPATH**/ ?>