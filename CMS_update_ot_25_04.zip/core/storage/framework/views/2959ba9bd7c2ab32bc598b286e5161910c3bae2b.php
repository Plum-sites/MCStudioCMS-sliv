<?php $__env->startSection('page_title', 'Бан-лист'); ?>
<?php $__env->startSection('body'); ?>
<form action="#" role="form" method="post">
	<?php echo csrf_field(); ?>
	<div class="col-md-12 mb-3 mt-1 p-0">
        <select class="form-control select-max-width font-size-for-mobile-17" id="server_id" name="server_id">
            <option value="" selected disabled>Выберите сервер для просмотра списка</option>
            <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e(@$server->id); ?>" data-server-id="" data-server-name="<?php echo e(@$server->name); ?>">Сервер <?php echo e(@$server->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div id="load_alert" class="alert alert-group alert-primary alert-dismissible fade show alert-icon" role="alert" style="display:none;">
		<div class="alert-group-prepend">
	        <span class="alert-group-icon text-">
	            <i id="load_alert_icon" class="fa fa-info-circle"></i>
	        </span>
	    </div>
	    <div class="alert-content">
	        <strong id="load_alert_text"></strong>
	    </div>
	</div>

    <div id="load_content" class="col-md-12 p-0" style="display:none;">
    	
    </div>
</form>

<script type="text/javascript">

    var hash_page = 1;
    window.location.hash = hash_page;
    
    $(window).on('hashchange', function() {
        if(window.location.hash) {
            var page = window.location.hash.replace('#', '');
            if(page == Number.NaN || page <= 0) {
                return false;
            } else {
                hash_page = page;
            }
        }
    });

    function load_content() {
    	$("#load_content").slideUp(500);
    	$.ajax({
            type: 'POST',
            url: '<?php echo e(route('banlist.list')); ?>',
            data: {
                action: 'list',
                _token: csrf_token,
                server_id: $('#server_id').val()
            },
            success: function (data) {
                setTimeout(function() {
                    $("#load_content").html(data).slideDown(500);
                    // $("#load_alert").slideDown(500);
                    // $("#load_alert_text").html('Список заблокированных игроков на сервере <b>' + $("#server_id option:selected").data('server-name') + '</b>');
                }, 500);
            },
            error: function(data) {
                if(data.status) {
                	$("#load_alert").slideDown(500);
                	$("#load_alert_text").html('Список в данный момент пуст');
                }
            }
        });
    }

    $(document).on('change', '#server_id', function () {
        hash_page = 1;
        window.location.hash = hash_page;
        load_content();
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/frontend/pages/banlist.blade.php ENDPATH**/ ?>