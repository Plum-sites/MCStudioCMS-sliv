<style type="text/css">
	body {
		padding: 0 !important;
	}
	.toastr {
		max-width: 100% !important;
	}
</style><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/frontend/layouts/visual.blade.php ENDPATH**/ ?>