<?php $__env->startSection('page_title', 'Правила'); ?>
<?php $__env->startSection('body'); ?>
<h2 class="text-center">Правила проекта</h2>
<p class="text-center">Обновлено 04.01.2021</p>
<p>Правил пока нет</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/frontend/pages/rules.blade.php ENDPATH**/ ?>