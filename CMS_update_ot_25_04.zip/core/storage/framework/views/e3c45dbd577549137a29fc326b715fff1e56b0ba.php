<script src="<?php echo e(asset('assets/admin/js/jquery.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/toastr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/main.js?upd=37')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/chart.min.old.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-notify.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/tagsinput.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/spectrum.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/knob.js?upd=1')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/fontawesome-iconpicker.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('assets/admin/js/snow.js?upd=3')); ?>"></script> --><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/layouts/scripts.blade.php ENDPATH**/ ?>