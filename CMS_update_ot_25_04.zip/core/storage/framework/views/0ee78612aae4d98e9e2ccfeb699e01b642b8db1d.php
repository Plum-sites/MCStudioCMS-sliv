<!-- Core JS  -->
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/svg-injector/dist/svg-injector.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/feather-icons/dist/feather.min.js')); ?>"></script>
<!-- Optional JS -->
<script src="<?php echo e(asset('assets/libs/in-view/dist/in-view.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/sticky-kit/dist/sticky-kit.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
<!-- Quick JS -->
<script src="<?php echo e(asset('assets/js/quick-website.js')); ?>"></script>
<!-- Toastr JS -->
<script src="<?php echo e(asset('assets/js/toastr.js')); ?>"></script>
<!-- McStudio JS -->
<script src="<?php echo e(asset('assets/js/knob.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/tools.js?u=6')); ?>"></script>
<script src="<?php echo e(asset('assets/js/prefix.js?u=1')); ?>"></script>
<script src="<?php echo e(asset('assets/js/mcstudio.js?u=23')); ?>"></script>
<?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/frontend/layouts/scripts.blade.php ENDPATH**/ ?>