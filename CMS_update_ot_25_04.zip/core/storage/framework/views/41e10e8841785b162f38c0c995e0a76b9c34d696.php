<?php $__env->startSection('page_icon', 'fa fa-bar-chart'); ?>
<?php $__env->startSection('page_name', 'Статистика сайта'); ?>
<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="tile-main">
            <div class="tile tile-smot">
                <div class="tile-head">

                </div>
            </div>
            <div class="tile">
                <div class="tile-body">
                    <div class="row">
                        <div class="col-lg-4 col-sm-6 px-2">
                            <div class="card" data-toggle="tooltips">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon icon-shape icon-md bg-primary shadow-primary text-white">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    </div>
                                    <!-- Title -->
                                    <h5 class="h3 font-weight-bolder mb-1"><?php echo e(@$users_count); ?> чел.</h5>
                                    <!-- Subtitle -->
                                    <span class="d-block text-sm text-muted font-weight-bold">
                                        Пользователей
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 px-2">
                            <div class="card" data-toggle="tooltips">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon icon-shape icon-md bg-danger shadow-primary text-white">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    </div>
                                    <!-- Title -->
                                    <h5 class="h3 font-weight-bolder mb-1"><?php echo e(@$onlines); ?> чел.</h5>
                                    <!-- Subtitle -->
                                    <span class="d-block text-sm text-muted font-weight-bold">
                                        Общий онлайн
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 px-2">
                            <div class="card" data-toggle="tooltips">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon icon-shape icon-md bg-warning shadow-primary text-white">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    </div>
                                    <!-- Title -->
                                    <h5 class="h3 font-weight-bolder mb-1"><?php echo e(@$payments_count); ?> шт.</h5>
                                    <!-- Subtitle -->
                                    <span class="d-block text-sm text-muted font-weight-bold">
                                        Количество платежей
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        
                        <div class="col-lg-4 col-sm-6 px-2">
                            <div class="card">
                                <div class="pl-4 mt-4 mb-0">
                                    <h5>Новые пользователи</h5>
                                </div>
                                <div class="card-body">
                                        <ul class="list-group list-group-flush p-0">
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item p-2" style="">
                                                <div class="widget-content">
                                                    <div class="widget-content-wrapper">
                                                        <div class="widget-content-left float-left mr-3">
                                                            <img width="35" style="border-radius:3px;" src="/view.php?user=<?php echo e((!@$user->username) ? 'default' : @$user->username); ?>&mode=3&size=35" alt="">
                                                        </div>
                                                        <div class="widget-content-left float-left">
                                                            <div class="widget-heading">
                                                                <?php if(@$user->username): ?>
                                                                <a href="<?php echo e(route('admin.usersList.user', @$user->id)); ?>">
                                                                    <?php echo e(@$user->username); ?>

                                                                </a>
                                                                <?php else: ?>
                                                                ******
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="widget-subheading mt-1 opacity-10">
                                                                <div class="badge badge-pill badge-success" style="border-radius:3px;"  data-toggle="tooltips" data-placement="left" title="Дата регистрации">
                                                                    <?php echo e(@$user->created_at); ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="widget-content-right float-right">
                                                            <div class="fsize-2 text-success" data-toggle="tooltips" data-placement="left" title="ID пользователя">
                                                                <span>
                                                                    #<?php echo e((!@$user->id) ? '0' : @$user->id); ?> 
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="clear-both"></div>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <div class="col-lg-4 col-sm-6 px-2">
                            <div class="card">
                                <div class="pl-4 mt-4 mb-0">
                                    <h5>Новые платежи</h5>
                                </div>
                                <div class="card-body">
                                        <ul class="list-group list-group-flush p-0">
                                                <?php $__empty_1 = true; $__currentLoopData = $users_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li class="list-group-item p-2" style="">
                                                    <div class="widget-content">
                                                        <div class="widget-content-wrapper">
                                                            <div class="widget-content-left float-left mr-3">
                                                                <img width="35" style="border-radius:3px;" src="/view.php?user=<?php echo e((!@$payment->user->username) ? 'default' : @$payment->user->username); ?>&mode=3&size=35" alt="">
                                                            </div>
                                                            <div class="widget-content-left float-left">
                                                                <div class="widget-heading">
                                                                    <?php if(@$payment->user->username): ?>
                                                                    <a href="<?php echo e(route('admin.usersList.user', @$payment->user_id)); ?>">
                                                                        <?php echo e(@$payment->user->username); ?>

                                                                    </a>
                                                                    <?php else: ?>
                                                                    ******
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="widget-subheading mt-1 opacity-10">
                                                                    <div class="badge badge-pill <?php if(@$payment->status == 0): ?> badge-danger <?php else: ?> badge-primary <?php endif; ?>" style="border-radius:3px;"  data-toggle="tooltips" data-placement="left" <?php if(@$payment->status == 0): ?> title="Не оплачено" <?php else: ?> title="Оплачено" <?php endif; ?>>
                                                                        
                                                                        <?php if(@$payment->money): ?>
                                                                        +<?php echo e(@$payment->money); ?> <?php echo e(@$general->currency_symbol); ?>

                                                                        <?php else: ?>
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="widget-content-right float-right">
                                                                <div class="fsize-2 text-success" data-toggle="tooltips" data-placement="left" title="ID платежа">
                                                                    <span>
                                                                        #<?php echo e((!@$payment->id) ? '0' : @$payment->id); ?> 
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="clear-both"></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p>Платежей пока нет</p>
                                                <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 px-2">
                                <div class="card">
                                    <div class="pl-4 mt-4 mb-0">
                                        <h5>Успешные платежи</h5>
                                    </div>
                                    <div class="card-body">
                                            <ul class="list-group list-group-flush p-0">
                                                <?php $__empty_1 = true; $__currentLoopData = $success_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($payment->status == 0) continue; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p>Платежей пока нет</p>
                                                <?php else: ?>
                                                
                                                <li class="list-group-item p-2" style="">
                                                    <div class="widget-content">
                                                        <div class="widget-content-wrapper">
                                                            <div class="widget-content-left float-left mr-3">
                                                                <img width="35" style="border-radius:3px;" src="/view.php?user=<?php echo e((!@$payment->user->username) ? 'default' : @$payment->user->username); ?>&mode=3&size=35" alt="">
                                                            </div>
                                                            <div class="widget-content-left float-left">
                                                                <div class="widget-heading">
                                                                    <?php if(@$payment->user->username): ?>
                                                                    <a href="<?php echo e(route('admin.usersList.user', @$payment->user_id)); ?>">
                                                                        <?php echo e(@$payment->user->username); ?>

                                                                    </a>
                                                                    <?php else: ?>
                                                                    ******
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="widget-subheading mt-1 opacity-10">
                                                                    <div class="badge badge-pill <?php if(@$payment->status == 0): ?> badge-danger <?php else: ?> badge-primary <?php endif; ?>" style="border-radius:3px;"  data-toggle="tooltips" data-placement="left" <?php if(@$payment->status == 0): ?> title="Не оплачено" <?php else: ?> title="Оплачено" <?php endif; ?>>
                                                                        
                                                                        <?php if(@$payment->money): ?>
                                                                        +<?php echo e(@$payment->money); ?> <?php echo e(@$general->currency_symbol); ?>

                                                                        <?php else: ?>
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="widget-content-right float-right">
                                                                <div class="fsize-2 text-success" data-toggle="tooltips" data-placement="left" title="ID платежа">
                                                                    <span>
                                                                        #<?php echo e((!@$payment->id) ? '0' : @$payment->id); ?> 
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="clear-both"></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- <div class="row">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title" style="font-size: 22px;">Статистика заказов по дням за месяц</h3>
            <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="lineChart1"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title" style="font-size: 22px;">Статистика заказов по месяцам за год</h3>
            <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="lineChart2"></canvas>
            </div>
        </div>
    </div>
</div> -->
<!-- 
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <h3 class="tile-title">Статистика заказов по годам</h3>
            <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="lineChart3"></canvas>
            </div>
        </div>
    </div>
</div>
 -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    var d1 = <?php echo json_encode(@$d1_payments); ?>;
    var m1 =  <?php echo json_encode(@$m1_payments); ?>;
    var data1 = {
        labels: d1,
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(47, 79, 79,0.2)",
                strokeColor: "rgba(47, 79, 79,1)",
                pointColor: "rgba(47, 79, 79,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: m1
            }
        ]
    };
    var options1 = {
        tooltipTemplate: "<%if (label){%><%=label %>: <%}%><%= value + ' шт.' %>",
        multiTooltipTemplate: "<%= value + ' шт.' %>",
    };

    var ctxl1 = $("#chart_payments").get(0).getContext("2d");
    var chart_payments = new Chart(ctxl1).Line(data1, options1);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>